<script setup>
import axios from 'axios';
import { useRoute, useRouter } from 'vue-router';

const route = useRoute();
const router = useRouter();

const back = () => {
    router.push('/pokemon')
}

const getData = async () =>{
    try {
        const {data} = await axios.get(`https://pokeapi.co/api/v2/pokemon/${route.params.name}`)
    } catch (error) {
        
    }
}
</script>

<template>
    <p>Nombre pokemon: {{ route.params.name }}</p>
    <button @click="back">Volver</button>    
</template>