<script setup>
import axios from 'axios';
import { onMounted, ref } from 'vue';
import { RouterLink } from 'vue-router';

const pokemons = ref([])

onMounted(async ()=>{
    try {
        const {data} = await axios.get('https://pokeapi.co/api/v2/pokemon')
        console.log(data.results)
        pokemons.value = data.results
    } catch (error) {
        
    }
})
</script>
<template>
    <h1>Pokemons 2026</h1>
    <ul class="list-disc">
        <li v-for="pokemon in pokemons">
            <RouterLink :to="`/pokemon/${pokemon.name}`" 
            class="text-blue-500 underline hover:text-blue-700"> {{ pokemon.name }}</RouterLink></li>
    </ul>
</template>